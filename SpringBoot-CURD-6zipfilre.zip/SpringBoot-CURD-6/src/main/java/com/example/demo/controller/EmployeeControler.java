package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.Impl.StudentServiceImpl;
import com.example.demo.views.Student;

@RestController
@RequestMapping("/api/student")
public class EmployeeControler {

	@Autowired
	private StudentServiceImpl studentServiceImpl;

	@PostMapping
	public ResponseEntity<Student> SaveStudent(@RequestBody Student student) {
		return new ResponseEntity<Student>(studentServiceImpl.SaveStudent(student), HttpStatus.CREATED);
	}

	@GetMapping()
	public List<Student> getAllDetails() {
		return studentServiceImpl.getAllDetails();
	}

	

	@GetMapping("{id}")
	public ResponseEntity<Student> getDetailById(@PathVariable("id") long studentid) {
		return new ResponseEntity<Student>(studentServiceImpl.getDetailById(studentid), HttpStatus.OK);

	}

	@PutMapping("{id}")
	public ResponseEntity<Student> updatedetails(@PathVariable("id") long id, @RequestBody Student employee) {
		return new ResponseEntity<Student>(studentServiceImpl.updatedetails(employee, id), HttpStatus.OK);

	}

	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteValue(@PathVariable("id") long id) {
		studentServiceImpl.deleteValue(id);
		return new ResponseEntity<String>("Employee Details Successfully Deleted", HttpStatus.OK);
	}

}
