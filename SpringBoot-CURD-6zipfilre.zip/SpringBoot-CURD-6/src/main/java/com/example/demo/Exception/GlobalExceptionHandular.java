package com.example.demo.Exception;

import java.util.Date;

import javax.xml.crypto.Data;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.example.demo.payload.ErrorMessage;

@ControllerAdvice
public class GlobalExceptionHandular {
	@ExceptionHandler(StudentException.class)
	public ResponseEntity<ErrorMessage> handleResoureceNotFoundException(StudentException exception,
			                                                                 WebRequest request) {
		
		ErrorMessage errorMessage = new ErrorMessage( new Date(), exception.getMessage(),
				
				request.getDescription(false));
		
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.BAD_REQUEST);

	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorMessage> Exception(Exception exception,
			                                                                 WebRequest request) {
		
		ErrorMessage errorMessage = new ErrorMessage( new Date(), exception.getMessage(),
				
				request.getDescription(false));
		
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.BAD_REQUEST);

	}

}
