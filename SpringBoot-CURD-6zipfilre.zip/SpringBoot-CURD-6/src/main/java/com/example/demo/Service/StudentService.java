package com.example.demo.Service;

import java.util.List;

import com.example.demo.views.Student;

public interface StudentService {
	
	Student SaveStudent(Student student);
	
	List<Student> getAllDetails ();
	
	Student  getDetailById( long id);
	
	Student updatedetails(Student student , long id );

	void  deleteValue(long id);
}
