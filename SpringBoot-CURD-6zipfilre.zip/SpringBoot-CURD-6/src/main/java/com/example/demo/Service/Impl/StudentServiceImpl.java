package com.example.demo.Service.Impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Exception.StudentException;
import com.example.demo.Repository.StudentRepository;
import com.example.demo.Service.StudentService;
import com.example.demo.views.Student;
@Service
public class StudentServiceImpl implements StudentService {
	
	private StudentRepository sturep;  
	
	public StudentServiceImpl(StudentRepository sturep) {
		this.sturep = sturep;
	}
	@Override
	public Student SaveStudent(Student student) {
		
		return sturep.save(student) ; 
	}
	@Override
	public List<Student> getAllDetails() { 
		
		return sturep.findAll(); 
	}
	@Override	
	public Student getDetailById(long id) {
		
		return sturep.findById(id).orElseThrow(()-> new StudentException("Student", "students", id));
	}
	@Override
	public Student updatedetails(Student student, long id) {
		
		Student existstu = sturep.findById(id).orElseThrow(()-> new StudentException("Student", "students", id));
		
		existstu.setFirstName(student.getFirstName());
		existstu.setLastName(student.getLastName()); 
		existstu.setEmail(student.getEmail());
		
		sturep.save(existstu);
		
		return existstu;
		
	}
	@Override
	public void deleteValue(long id) {
		// TODO Auto-generated method stub
		sturep.findById(id).orElseThrow(()-> new StudentException("Student", "students", id));
		sturep.deleteById(id );
	}
	

	
}
