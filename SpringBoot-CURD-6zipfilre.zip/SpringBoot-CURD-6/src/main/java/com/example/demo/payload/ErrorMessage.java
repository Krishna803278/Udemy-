package com.example.demo.payload;

import java.util.Date;

public class ErrorMessage {

	private Date timetamp;
	private String meassage;
	private String details;
	public ErrorMessage(Date timetamp, String meassage, String details) {
		super();
		this.timetamp = timetamp;
		this.meassage = meassage;
		this.details = details;
	}
	public String getDetails() {
		return details;
	}
	public String getMeassage() {
		return meassage;
	}
	public Date getTimetamp() {
		return timetamp;
	}
}
