package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.Exception.StudentException;
import com.example.demo.Repository.StudentRepository;
import com.example.demo.Service.Impl.StudentServiceImpl;
import com.example.demo.views.Student;

@RunWith(SpringRunner.class)
public class StudentServiceImplTest {
 
	@Mock
	private StudentRepository sturepMock;
	 
	@InjectMocks
	private StudentServiceImpl studentServiceImplMock;


	@Test
	public void SaveStudentTest() {
		 
		Student student=new Student();
		student.setId(1); 
		
		when(sturepMock.save(student)).thenReturn(student);
		student =studentServiceImplMock.SaveStudent(student);
		assertNotNull(student);
		
	}
	@Test
	public void getAllDetailsTest() {
		List<Student> list = new ArrayList();
		
		 
		when(sturepMock.findAll()).thenReturn(list);
		list = studentServiceImplMock.getAllDetails();
		assertNotNull(list);
	}
	@Test
	public void getDetailById() { 
		Optional<Student> student = Optional.of(new Student()); 
		long id = 1;
		when(sturepMock.findById(id)).thenReturn(student);
		studentServiceImplMock.getDetailById(id);
		assertNotNull(student);
	} 
	@Test
	public void updatedetails() {
		
		Optional<Student> student  = Optional.of(new Student());
		
		long id = 1;
	String name="name";
	
		Student existstu=new Student();
		existstu.setId(1);
		when(sturepMock.findById(id)).thenReturn(student);

		when(sturepMock.save(existstu)).thenReturn(existstu);
		existstu= studentServiceImplMock.updatedetails(existstu, id);
		assertNotNull(existstu);
	} 
	
	@Test
	public void deleteValue() {
		
		
		Optional<Student> student=Optional.of(new Student());
		long  id=1;
		when(sturepMock.findById(id)).thenReturn(student);
		
		Student existstu=new Student();
		existstu.setId(1);
		
		 studentServiceImplMock.deleteValue(id);
		 assertNotNull(existstu);
	} 

}
