package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.Service.StudentService;
import com.example.demo.views.Student;

@RunWith(SpringRunner.class)
public class StudentControlerTest {

	@Mock
	private StudentService stdsrsmock;

	@InjectMocks
	private StudentControlerTest studentControlermock;

//	@Test
//	public void SaveStudent(Student student2) {
//		Student student = new Student();
//		student.setId(1);
//		when(stdsrsmock.SaveStudent(student)).thenReturn(student);
//		ResponseEntity<Student> responseEntity = studentControlermock.SaveStudent(student);
//		assertEquals(HttpStatus.CREATED.value(), responseEntity.getStatusCodeValue());
//		assertNotNull(responseEntity);
//
//	}
//
//	@Test
//	public void getAllDetails() {
//		Student student = new Student();
//		List<Student> list = new ArrayList();
//		when(stdsrsmock.getAllDetails()).thenReturn(list);
//		studentControlermock.getAllDetails();
//		assertNotNull(list);
//
//	}
//
//	@Test
//	public void getDetailById() {
//		Student student = new Student();
//		student.setFirstName("raju");
//		long id = 1;
//		when(stdsrsmock.getDetailById(id)).thenReturn(student);
//		ResponseEntity<Student> responseEntity = studentControlermock.getDetailById(id);
//		assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
//		assertNotNull(responseEntity);
//	}
//
//	@Test
//	public void updatedetails() {
//		Student student = new Student();
//		student.setFirstName("raju");
//		long id = 1;
//		when(stdsrsmock.updatedetails(student, id)).thenReturn(student);
//		ResponseEntity<Student> responseEntity = studentControlermock.updatedetails(id, student);
//		assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
//		assertNotNull(responseEntity);
//	}
//
//	@Test
//	public void deleteValueTest() {
//		Student student = new Student();
//		student.setFirstName("raju");
//		long id = 1;
//
//		// Mockito.when( stdsrsmock.deleteValue(id)).thenReturn(student);
//
//		ResponseEntity<String> responseEntity = studentControlermock.deleteValue(id);
//		assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
//		assertNotNull(responseEntity);
//	}

}
